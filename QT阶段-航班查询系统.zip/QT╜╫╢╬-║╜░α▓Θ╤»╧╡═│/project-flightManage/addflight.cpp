﻿#include "addflight.h"
#include "ui_addflight.h"

AddFlight::AddFlight(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::AddFlight)
{
    ui->setupUi(this);
    speech = new QTextToSpeech();
    speech->setRate(0.5);
}

AddFlight::~AddFlight()
{
    delete ui;
}

void AddFlight::on_btninsert_clicked()
{
    if(ui->lineEdit_flight->text() == "")
    {
        QMessageBox::warning(this,"警告","航班信息不能为空!");
        return ;
    }
    QString sql = QString("insert into flight values('%1','%2','%3','%4','%5',%6,'%7',%8)")
            .arg(ui->lineEdit_flight->text()).arg(ui->lineEdit_departure->text())
            .arg(ui->lineEdit_destination->text()).arg(ui->lineEdit_data->text())
            .arg(ui->lineEdit_time->text()).arg(ui->lineEdit_price->text().toInt())
            .arg(ui->lineEdit_type->text().toStdString().c_str()).arg(ui->lineEdit_num->text().toInt());
    QSqlQuery query;
    if(query.exec(sql))
    {
        QMessageBox::information(this,"提示","insert success");
    }
    else {
        QMessageBox::warning(this,"警告","insert failed");
    }
}

void AddFlight::on_btnbackl_clicked()
{
    QMessageBox::information(this,"提示","进入航班管理界面");
    speech->say("进入航班管理界面");
    flightManage *fligh = new flightManage();
    fligh->show();
    this->close();
}

void AddFlight::on_btnaddtickets_clicked()
{
    int num = ui->lineEdit_num->text().toInt();
    qDebug() << "num: " << num;
    QString sql = QString("update flight set num = %1 where flight_number = '%2';")
            .arg(num).arg(ui->lineEdit_flight->text());
    QSqlQuery query;
    if(!query.exec(sql))
    {
        QMessageBox::warning(this,"警告","更新票数失败!");
    }
    else {
        QMessageBox::information(this,"提示","更新成功");
    }
}
