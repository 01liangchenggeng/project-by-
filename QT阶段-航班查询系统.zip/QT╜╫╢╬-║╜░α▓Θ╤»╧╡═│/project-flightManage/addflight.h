﻿#ifndef ADDFLIGHT_H
#define ADDFLIGHT_H

#include <QMainWindow>
#include <QtDebug>
#include <QSqlDatabase>
#include <QSqlQuery>
#include <QStandardItem>
#include <QPixmap>
#include <QMessageBox>
#include <QTextToSpeech>

#include "flightmanage.h"

namespace Ui {
class AddFlight;
}

class AddFlight : public QMainWindow
{
    Q_OBJECT

public:
    explicit AddFlight(QWidget *parent = nullptr);
    ~AddFlight();

    QTextToSpeech *speech;

private slots:
    void on_btninsert_clicked();

    void on_btnbackl_clicked();

    void on_btnaddtickets_clicked();

private:
    Ui::AddFlight *ui;
};

#endif // ADDFLIGHT_H
