﻿#include "buytickets.h"
#include "ui_buytickets.h"

BuyTickets::BuyTickets(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::BuyTickets)
{
    ui->setupUi(this);
//    qDebug() << Ticket << " " << Flight << Price;
    speech = new QTextToSpeech();
    speech->setRate(0.5);
}

BuyTickets::~BuyTickets()
{
    delete ui;
}

void BuyTickets::get_message(QString sumtickets, QString flight_number)
{
//    qDebug() << sumtickets << " " << flight_number;
    this->Ticket = sumtickets;
    this->Flight = flight_number;
    ui->label_flight->setText(Flight);
    ui->label_sumtickets->setText(Ticket);
    int num = sumtickets.toInt();
    QString sql = QString("select price from flight where flight_number = '%1';").arg(flight_number);
    QSqlQuery query;
    if(!query.exec(sql))
    {
        QMessageBox::warning(this,"警告","查找错误!");
    }
    else {
        query.next();
        int price = query.value(0).toInt();
        QString p = QString::number(price * num);
        this->Price = p;
        ui->label_sumprice->setText(Price);
//        qDebug() << "BuyTickets get_message: " <<Ticket << " " << Flight << Price;
    }
}

//确认支付
void BuyTickets::on_btnpay_clicked()
{
    //先获取数据库中对应的票数,-1,再更新票数
    QString sql = QString("select num from flight where flight_number = '%1';").arg(ui->label_flight->text());
    QSqlQuery query;
    if(!query.exec(sql))
    {
        QMessageBox::warning(this,"警告","支付失败!");
    }
    else {
        query.next();
        int tickets = ui->label_sumtickets->text().toInt();
//        qDebug() << "tickets: " << tickets << "";
        if(tickets > query.value(0).toInt())
        {
            QMessageBox::warning(this,"警告","购票数量过多!");
        }
        else
        {
            QMessageBox::information(this,"提示","支付成功");
            int num = query.value(0).toInt()-tickets;
//            qDebug() << "num : " << num;
            QString sql1 = QString("update flight set num = %1 where flight_number = '%2';")
                    .arg(num).arg(ui->label_flight->text());
            if(!query.exec(sql1))
            {
                QMessageBox::warning(this,"警告","更新失败");
            }
            else {
//                QMessageBox::information(this,"提示","更新成功");
                QString sql = QString("select num from flight where flight_number = '%1';").arg(ui->label_flight->text());
                QSqlQuery query;
                query.next();
//                qDebug() << query.value(0).toInt() << "==========";
                QMessageBox::information(this,"提示","进入航班管理界面");
                speech->say("进入航班管理系统");
                flightManage *fligh = new flightManage();
                fligh->show();
                this->hide();
            }
        }
    }
}

//取消支付
void BuyTickets::on_btncancle_clicked()
{
    QMessageBox::information(this,"提示","进入航班管理界面");
    speech->say("进入航班管理系统");
    flightManage *fligh = new flightManage();
    fligh->show();
    this->close();
}
