﻿#ifndef BUYTICKETS_H
#define BUYTICKETS_H

#include <QMainWindow>
#include <QMainWindow>
#include <QtDebug>
#include <QSqlDatabase>
#include <QSqlQuery>
#include <QStandardItem>
#include <QMessageBox>
#include <QPixmap>
#include <QTimer>
#include <QTime>
#include <QDate>
#include <QDateTime>
#include <QTextToSpeech>

#include "flightmanage.h"

namespace Ui {
class BuyTickets;
}

class BuyTickets : public QMainWindow
{
    Q_OBJECT

public:
    explicit BuyTickets(QWidget *parent = nullptr);
    ~BuyTickets();
    void get_message(QString sumtickets,QString flight_number);
    QString Ticket;
    QString Price;
    QString Flight;

    QTextToSpeech *speech;

private slots:
    void on_btnpay_clicked();

    void on_btncancle_clicked();


private:
    Ui::BuyTickets *ui;


};

#endif // BUYTICKETS_H
