﻿#include "flightmanage.h"
#include "ui_flightmanage.h"

flightManage::flightManage(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::flightManage)
{
    ui->setupUi(this);
    t = 0;
    tabel_init();
    sql_init("./flight.db");
    timer.setInterval(1000);
    connect(&timer,&QTimer::timeout,this,&flightManage::time_out);
    qDebug() << QTextToSpeech::availableEngines(); //打印QT支持的语音引擎
    speech = new QTextToSpeech();
    speech->setPitch(0.0);//设置音高，范围-1.0~1.0，默认为系统音高
    speech->setVolume(1.0);//设置音量，范围0.0~1.0，默认为系统音量
    speech->setRate(-0.1);//设置语音速度
    speech->say("欢迎使用航班查询系统");//设置语音文本
}

flightManage::~flightManage()
{
    delete ui;
    database.close();
    timer.stop();
}

void flightManage::time_out()
{
    QString time = QTime::currentTime().toString("hh:mm:ss");
    ui->lcdNumber->display(time);
    QString date = QDate::currentDate().toString("yyyy/MM/dd");
    ui->label_data->setText(date);
    for(int i = 0; i < count; i++)
    {
        QString message = model->data(model->index(i,4)).toString();//获取时间
//        qDebug() << message;
        QStringList splite_sql_time = message.split(":");//将时间分割成两个部分
//        qDebug() << splite.at(0);
        QStringList splite_current_time = time.split(":");
//        qDebug() << splite_current_time.at(0);
        if(splite_sql_time.at(0) == splite_current_time.at(0))
        {
            int now = splite_sql_time.at(1).toInt() - splite_current_time.at(1).toInt();
            if(0 < now && now  <= 15)
            {
                if(t == 0)
                {
                    QString flight = model->data(model->index(i,0)).toString();
                    speech->say("乘坐航班:" + flight + "的旅客请注意，飞机即将在十五分钟后起飞,请带上私人物品前往飞机");
                    t = 1;
                }
            }
        }
    }
}

//初始化数据库
void flightManage::sql_init(QString sqlpath)
{
    database = QSqlDatabase::addDatabase("QSQLITE");
    database.setDatabaseName(sqlpath);
    database.open();
    if(!database.isOpen())
    {
        QMessageBox::warning(this,"警告","open flight.db failed!");
        return ;
    }
    else {
//        QMessageBox::information(this,"提示","open flight.db success");
        QString sql = QString("create table if not exists flight(flight_number text unique,departure text,"
                              "destination text,data text,time text,price int,type char,num int);");
        if(sql_exec(sql))
        {
//            QMessageBox::information(this,"提示","create tabel success");
                QString sql1 = QString("create table if not exists user(userid text unique,password text);");
                if(!sql_exec(sql1))
                {
                    QMessageBox::warning(this,"警告","create user failed!");
                }
        }
        else {
            QMessageBox::warning(this,"警告","create tabel failed!");
        }
    }
    QString sql ="select * from flight;";
    sql_select(sql);//每次启动程序就先将数据库中的信息遍历到tabelview中
    timer.start(1);//启动定时器
}

//初始化tabelview
void flightManage::tabel_init()
{
    model = new QStandardItemModel(this);
    model->setHorizontalHeaderItem(0,new QStandardItem("航班号"));
    model->setHorizontalHeaderItem(1,new QStandardItem("出发地"));
    model->setHorizontalHeaderItem(2,new QStandardItem("目的地"));
    model->setHorizontalHeaderItem(3,new QStandardItem("日期"));
    model->setHorizontalHeaderItem(4,new QStandardItem("时间"));
    model->setHorizontalHeaderItem(5,new QStandardItem("价格"));
    model->setHorizontalHeaderItem(6,new QStandardItem("类型"));
    model->setHorizontalHeaderItem(7,new QStandardItem("数量"));
    ui->tableView->setModel(model);
}

//执行sql语句
bool flightManage::sql_exec(QString sql)
{
    qDebug() << sql;
    QSqlQuery query;
    if(query.exec(sql))
    {
        return true;
    }
    else {
        return false;
    }
}

//全部查询
bool flightManage::sql_select(QString sql)
{
    //执行 构造函数中可以执行sql语句
    QSqlQuery query(sql);
//    model->clear();
    for( int i = 0;i < count; i++)
    {
        model->removeRow(i);
    }

    count = 0;
    //获取操作结果
    while(query.next())
    {
        //获取每一次记录
//        QString id = query.value(0).toString();
//        QString name = query.value(1).toString();
//        QString price = query.value(2).toString();
//        qDebug() << id << " " << name << " " << price;

        model->setItem(count, 0 ,new QStandardItem(query.value(0).toString()));
        model->setItem(count , 1 , new QStandardItem(query.value(1).toString()));
        model->setItem(count , 2 , new QStandardItem(query.value(2).toString()));
        model->setItem(count , 3 , new QStandardItem(query.value(3).toString()));
        model->setItem(count , 4 , new QStandardItem(query.value(4).toString()));
        model->setItem(count , 5 , new QStandardItem(query.value(5).toString()));
        model->setItem(count , 6 , new QStandardItem(query.value(6).toString()));
        model->setItem(count , 7 , new QStandardItem(query.value(7).toString()));
        count ++;
    }
}

//管理员按钮
void flightManage::on_btn_menager_clicked()
{
    speech->say("进入管理员登录界面");
    Manager *manager = new Manager(this);
    manager->show();
    this->hide();
}

//购票按钮
void flightManage::on_btn_buy_tickets_clicked()
{
    if(ui->line_flight->text() != "" && ui->line_tickets->text() != ""
            && ui->line_departure->text() != "" && ui->line_destination->text() != "")
    {
        QString message = QString("您的购票信息如下:\n航班:%1\t出发地:%2\n目的地:%3\t数量:%4")
                .arg(ui->line_flight->text()).arg(ui->line_departure->text())
                .arg(ui->line_destination->text()).arg(ui->line_tickets->text());
        int ret = QMessageBox::question(this,"购票信息",message);
        if(ret == QMessageBox::Yes)
        {
            speech->say("购票信息确认成功，进入用户注册登录界面");
            UserRigeste *user = new UserRigeste();
            user->get_message(ui->line_tickets->text(),ui->line_flight->text());
            user->show();
            this->close();
        }
    }
    else {
        if(ui->line_tickets->text() == "0")
        {
            QMessageBox::warning(this,"警告","购票数量需要>=1!");
        }
        else {
            QMessageBox::warning(this,"警告","请输入购票信息!");
        }
    }
}

//排序
void flightManage::on_btnsort_clicked()
{
    QString sql = "select * from flight order by flight_number asc;";
    sql_select(sql);
    QMessageBox::information(this,"提示","升序排序完毕");
}

//查询
void flightManage::on_btnsearch_clicked()
{
    if(ui->linesearch->text() == "")
    {
        QMessageBox::warning(this,"警告","查询信息为空!");
    }
    else {
        QString sql = QString("select * from flight where data = '%1';").arg(ui->linesearch->text());
        sql_select(sql);
        QMessageBox::information(this,"提示","查询完毕");
    }
}
