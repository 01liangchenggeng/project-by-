﻿#ifndef FLIGHTMANAGE_H
#define FLIGHTMANAGE_H

#include <QMainWindow>
#include <QtDebug>
#include <QSqlDatabase>
#include <QSqlQuery>
#include <QStandardItem>
#include <QMessageBox>
#include <QPixmap>
#include <QTimer>
#include <QTime>
#include <QDate>
#include <QDateTime>
#include <QTextToSpeech>
#include <QList>

#include "manager.h"
#include "userrigeste.h"
#include "buytickets.h"
extern "C"
{
    #include <unistd.h>
    #include <stdlib.h>
}

namespace Ui {
class flightManage;
}

class flightManage : public QMainWindow
{
    Q_OBJECT

public:
    explicit flightManage(QWidget *parent = nullptr);
    ~flightManage();
    QTextToSpeech *speech;
    int t;
private slots:
    void on_btn_menager_clicked();

    void on_btn_buy_tickets_clicked();

    void sql_init(QString sqlpath);
    void tabel_init();
    bool sql_exec(QString sql);
    void time_out();
    void on_btnsort_clicked();

    bool sql_select(QString sql);
    void on_btnsearch_clicked();

private:
    Ui::flightManage *ui;
    QSqlDatabase database;
    QStandardItemModel *model;
    QSqlDatabase sql;
    int count; //计数显示的航班信息
    QTimer timer;

};

#endif // FLIGHTMANAGE_H
