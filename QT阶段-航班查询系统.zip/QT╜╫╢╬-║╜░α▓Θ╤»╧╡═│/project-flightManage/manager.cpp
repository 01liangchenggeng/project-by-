﻿#include "manager.h"
#include "ui_manager.h"

Manager::Manager(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::Manager)
{
    ui->setupUi(this);
    speech = new QTextToSpeech();
    speech->setRate(0.5);
}

Manager::~Manager()
{
    delete ui;
}

//登录
void Manager::on_btnlogin_clicked()
{
    QString userid = ui->lineid->text();
    QString password = ui->linepassword->text();
//    qDebug() << "账号: " << userid << " 密码: " << password;
    if(userid == "3150572306" && password == "123456")
    {
        QString welcome = QString("登录成功,欢迎您,管理员%1").arg(userid);
        QMessageBox::information(this,"提示",welcome);
        speech->say("进入后天管理界面");
        AddFlight *flight = new AddFlight(this);
        flight->show();
        this->hide();
    }
    else {
        QMessageBox::warning(this,"警告","登陆失败,请检查用户名或密码是否正确!");
    }
}

//取消
void Manager::on_btncancle_clicked()
{
    QMessageBox::information(this,"提示","进入航班管理界面");
    speech->say("进入航班管理系统");
    this->parentWidget()->show();
    this->close();
}
