﻿#ifndef MANAGER_H
#define MANAGER_H

#include <QMainWindow>
#include <QtDebug>
#include <QSqlDatabase>
#include <QSqlQuery>
#include <QStandardItem>
#include <QPixmap>
#include <QMessageBox>
#include <QTextToSpeech>

#include "addflight.h"

namespace Ui {
class Manager;
}

class Manager : public QMainWindow
{
    Q_OBJECT

public:
    explicit Manager(QWidget *parent = nullptr);
    ~Manager();

    QTextToSpeech *speech;

private slots:
    void on_btnlogin_clicked();

    void on_btncancle_clicked();

private:
    Ui::Manager *ui;
};

#endif // MANAGER_H
