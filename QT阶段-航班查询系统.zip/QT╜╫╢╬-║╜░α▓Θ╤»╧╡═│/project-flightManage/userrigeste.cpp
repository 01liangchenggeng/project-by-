﻿#include "userrigeste.h"
#include "ui_userrigeste.h"

UserRigeste::UserRigeste(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::UserRigeste)
{
    ui->setupUi(this);
    speech = new QTextToSpeech();
    speech->setRate(0.5);
}

UserRigeste::~UserRigeste()
{
    delete ui;
}

void UserRigeste::get_message(QString sumtickets, QString flight_number)
{
    this->Ticket = sumtickets;
    this->Flight = flight_number;
    int num = sumtickets.toInt();
    QString sql = QString("select price from flight where flight_number = '%1';").arg(flight_number);
    QSqlQuery query;
    if(!query.exec(sql))
    {
        QMessageBox::warning(this,"警告","查找错误!");
    }
    else {
        query.next();
        int price = query.value(0).toInt();
        QString p = QString::number(price * num);
//        qDebug() << "UserRigeste get_message: " <<Ticket << " " << Flight;
    }
}

//注册
void UserRigeste::on_btn_registe_clicked()
{
    if(ui->lineEdit_surepassword->text() != ui->lineEdit_userpassword->text())
    {
        QMessageBox::warning(this,"警告","两次输入的密码不一致!");
        return ;
    }
    QString password = ui->lineEdit_surepassword->text();
    QCryptographicHash hash(QCryptographicHash::Md5);
    hash.addData(password.toUtf8());
    QByteArray result = hash.result();
    password = result.toHex();
    QString sql = QString("insert into user values('%1','%2');")
            .arg(ui->lineEdit_userid->text()).arg(password);
//    qDebug() << password;
    QSqlQuery query;
    if(!query.exec(sql))
    {
        QMessageBox::warning(this,"警告","用户已存在!");
    }
    else {
        QMessageBox::information(this,"提示","注册成功");
    }
}

//重置
void UserRigeste::on_btn_reset_clicked()
{
    ui->lineEdit_userid->setText("");
    ui->lineEdit_surepassword->setText("");
    ui->lineEdi_username->setText("");
    ui->lineEdit_userpassword->setText("");
}

//返回
void UserRigeste::on_btn_back_clicked()
{
    QMessageBox::information(this,"提示","进入航班管理界面");
    speech->say("进入航班管理系统");
    flightManage *fligh = new flightManage();
    fligh->show();
    this->close();
}

//登录
void UserRigeste::on_btn_login_clicked()
{
    if(ui->lineEdit_userid->text() == "")
    {
        return ;
    }
    QString sql = QString("select * from user where userid = '%1';").arg(ui->lineEdit_userid->text());
    QSqlQuery query;
    if(!query.exec(sql))
    {
        QMessageBox::warning(this,"警告","查无此用户!");
    }
    else {
        //执行sql语句后query的recond记录是在第一条有效数据之前，需要使用next()或first();
        query.next();
        if(query.value(0).toString() != ui->lineEdit_userpassword->text())
        {
            QMessageBox::warning(this,"警告","密码错误!");
        }
        else {
            speech->say("登陆成功，进入购票支付界面");
            QMessageBox::information(this,"提示","登陆成功");
            BuyTickets *tickets = new BuyTickets();
//            qDebug() << "UserRigeste new " << Ticket << Flight;
            tickets->get_message(Ticket,Flight);
            tickets->show();
            this->hide();
        }
    }
}
