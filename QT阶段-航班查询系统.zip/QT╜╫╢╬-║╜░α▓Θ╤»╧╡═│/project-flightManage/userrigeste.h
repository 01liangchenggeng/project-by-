﻿#ifndef USERRIGESTE_H
#define USERRIGESTE_H

#include <QMainWindow>
#include <QtDebug>
#include <QSqlDatabase>
#include <QSqlQuery>
#include <QStandardItem>
#include <QPixmap>
#include <QMessageBox>
#include <QTextToSpeech>
#include <QCryptographicHash>

#include "buytickets.h"
#include "flightmanage.h"

namespace Ui {
class UserRigeste;
}

class UserRigeste : public QMainWindow
{
    Q_OBJECT

public:
    explicit UserRigeste(QWidget *parent = nullptr);
    ~UserRigeste();

    void get_message(QString sumtickets,QString flight_number);

    QString Ticket;
    QString Flight;

    QTextToSpeech *speech;

private slots:
    void on_btn_registe_clicked();

    void on_btn_reset_clicked();

    void on_btn_back_clicked();

    void on_btn_login_clicked();

private:
    Ui::UserRigeste *ui;
};

#endif // USERRIGESTE_H
