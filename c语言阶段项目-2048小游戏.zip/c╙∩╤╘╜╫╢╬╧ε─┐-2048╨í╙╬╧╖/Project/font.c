#include "font.h"

struct LcdDevice* lcd=NULL;//lcd屏幕指针
font *f=NULL;//字体指针
bitmap *bm=NULL;//内存映射指针

//初始化Lcd
struct LcdDevice *init_lcd(const char *device)
{
	//申请空间
	struct LcdDevice* lcd = malloc(sizeof(struct LcdDevice));
	if(lcd == NULL)
	{
		return NULL;
	} 

	//1打开设备
	lcd->fd = open(device, O_RDWR);
	if(lcd->fd < 0)
	{
		perror("open lcd fail");
		free(lcd);
		return NULL;
	}
	
	//映射
	lcd->mp = mmap(NULL,800*480*4,PROT_READ|PROT_WRITE,MAP_SHARED,lcd->fd,0);

	return lcd;
}
//初始化字体大小
void font_init(int num)
{
	//初始化Lcd
	lcd = init_lcd("/dev/fb0");
			
	//打开字体----210板子没有----需要把6818中字体文件传输到210的开发板上
	f = fontLoad("/usr/share/fonts/DroidSansFallback.ttf");
	  
	//字体大小的设置：范围是1~72，但尽量选择字库中的字体大小
	fontSetSize(f,num);
}

//创建一个宽为W,高为H的颜色为mapcolor的画布，
void create_map(int W,int H,unsigned int mapcolor)
{
	unsigned int A,R,G,B;
	A= (mapcolor>>24);
	R= (mapcolor>>16)&0xff;
	G= (mapcolor>> 8)&0xff;
	B= (mapcolor>> 0)&0xff;
	bm = createBitmapWithInit(W,H,4,getColor(A,B,G,R)); 
}

//在画布的（X,Y）坐标开始中写一个fontcolor颜色的buf文字
void create_font(int X,int Y,char *buf,unsigned int fontcolor)
{
	unsigned int A,R,G,B;
	A=  fontcolor>>24;
	R= (fontcolor>>16)&0xff;
	G= (fontcolor>> 8)&0xff;
	B= (fontcolor>> 0)&0xff;
	fontPrint(f,bm,X,Y,buf,getColor(A,B,G,R),0);
	
}

// int main()
// {
// 	//开启画板,初始化字体大小
// 	font_init(72);
	
// 	char str[64];
// 	sprintf(str,"智能停车系统");
// 	create_map(200,600,0x000000ff);
// 	create_font(50,50,str,0x00ff0000);
// 	//把字体框输出到LCD屏幕上,画框左上角的坐标为（200，200）
// 	show_font_to_lcd(lcd->mp,200,200,bm);
	
// 	//关闭字体，关闭画板
// 	fontUnload(f);
// 	destroyBitmap(bm);	
// }
