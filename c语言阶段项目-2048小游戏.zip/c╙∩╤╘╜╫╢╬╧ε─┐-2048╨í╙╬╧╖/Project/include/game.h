/*
 * @Author: 梁程耿
 * @Date: 2022-08-08 19:30:19
 * @LastEditTime: 2022-08-10 12:49:16
 * @FilePath: \vmshare\kaifaban\Project\include\game.h
 * @Description:
 * Software:VSCode,env:
 * @version:
 */
#ifndef __GAME_H_
#define __GAME_H_

int game_over;       //是否游戏结束了
char score_buff[10]; //保存实时积分
int now_score;       //实时积分
char score_buff[10]; //保存实时积分

//棋盘矩阵的初始化
int array[4][4];

void Game_Loading(game_p head);
void Game_Begin(game_p head);
void Play_Game(game_p head);
void draw_matrix(game_p head);
void lcd_draw_point(int x, int y, int color);
void lcd_draw_dect(int x0, int y0, int w, int h, int color);
int rectangle_get_zero_num();
void init_matrix(game_p head);
int rectangle_set_value(int z, int value);
int get_bmp_files_index(int x);
int change_matrix();
void rand_matrix(game_p head);
int move_judge();
void fin_left();
void fin_right();
void fin_up();
void fin_down();

#endif