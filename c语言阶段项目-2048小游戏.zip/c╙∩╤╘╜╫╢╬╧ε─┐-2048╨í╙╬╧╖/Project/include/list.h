/*
 * @Author: 梁程耿
 * @Date: 2022-08-05 09:42:37
 * @LastEditTime: 2022-08-10 08:48:58
 * @FilePath: \vmshare\kaifaban\Project\include\list.h
 * @Description:
 * Software:VSCode,env:
 * @version:
 */
#ifndef __LIST_H_
#define __LIST_H_

//链表结构体
typedef struct game
{
    int data;          //积分
    char user[20];     //账户
    char password[20]; //密码
    struct game *next;
    struct game *prev;
} game_s, *game_p;
//初始化链表
game_p Init_List();
//创建节点
game_p Creat_New_Node(char *id, char *pw, int read_data);
//尾插插入节点
void Insert_New_Node_By_Tail(game_p head, game_p new_node);
//遍历链表
void Show_List(game_p head);
//显示前十
void Show_Score(game_p Head);
//任意位置增加节点
void Add_Node_By_Any_Position(game_p head);
// //冒泡排序
// void Merge_List_Bubble(game_p head);
//选择排序
void Merge_List_Choice(game_p head);
//寻找相同的账号
game_p Find_id(game_p Head, char *id);
//删除节点
void Delete_Node(game_p Pos);

#endif