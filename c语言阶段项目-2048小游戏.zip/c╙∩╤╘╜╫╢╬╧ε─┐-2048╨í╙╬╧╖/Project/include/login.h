/*
 * @Author: 梁程耿
 * @Date: 2022-08-08 19:31:07
 * @LastEditTime: 2022-08-10 12:49:39
 * @FilePath: \vmshare\kaifaban\Project\include\login.h
 * @Description:
 * Software:VSCode,env:
 * @version:
 */
#ifndef __LOGIN_H_
#define __LOGIN_H_

int flag_user;            //点击输入账号时键盘弹出收回
int flag_password;        //点击输入密码时键盘弹出收回
int flag_login;           //点击登录时键盘弹出收回
int flag_register;        //点击注册时键盘弹出收回
int flag_complete;        //记录是否按下完成键
int flag_refuse;          //记录是否按下取消键
int count_user_input;     //记录输入多少个账号数字
int count_password_input; //记录输入多少个密码数字
char user[15];            //记录输入的账号
char password[15];        //记录输入的密码
char now_user[15];        //保存进行游戏时的用户

void Login(game_p head);

#endif