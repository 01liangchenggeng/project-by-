/*
 * @Author: 梁程耿
 * @Date: 2022-07-29 15:50:18
 * @LastEditTime: 2022-08-05 09:41:47
 * @FilePath: \vmshare\kaifaban\Project\myhead.h
 * @Description:
 * Software:VSCode,env:
 * @version:
 */
#ifndef __MYHEAD_H_
#define __MYHEAD_H_

#include <stdio.h>
#include <string.h>
#include <strings.h>
#include <unistd.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <fcntl.h>
#include <errno.h>
#include <stdlib.h>
#include <dirent.h>
#include <sys/mman.h>
#include <linux/input.h>
#include <time.h>



#endif