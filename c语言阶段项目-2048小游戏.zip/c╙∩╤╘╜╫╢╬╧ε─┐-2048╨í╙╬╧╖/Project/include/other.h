/*
 * @Author: 梁程耿
 * @Date: 2022-08-08 19:30:23
 * @LastEditTime: 2022-08-08 19:53:30
 * @FilePath: \vmshare\kaifaban\Project\other.h
 * @Description:
 * Software:VSCode,env:
 * @version:
 */
#ifndef __OTHER_H_
#define __OTHER_H_

#define device_path "/dev/fb0"
#define touch_path "/dev/input/event0"

int *Share_Addr; //设置共享内存
int Lcd_Fd;      //记录打开设备状态
int touch_fd;    //记录打开触摸屏状态
font *f;         //字体指针
bitmap *bm;      //内存映射指针

int x, y; //记录刚开始点击时的的x，y坐标
int image; //记录处于哪个画面

void Init_Device();
int show_bmp(char *pathname, int width, int height, int x, int y);
void Close_Device();
int Get_Position(int *x, int *y);

#endif