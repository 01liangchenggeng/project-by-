/*
 * @Author: 梁程耿
 * @Date: 2022-08-04 13:59:47
 * @LastEditTime: 2022-08-09 08:56:22
 * @FilePath: \vmshare\kaifaban\Project\main.c
 * @Description:
 * Software:VSCode,env:
 * @version:
 */
#include "myhead.h"
#include "list.h"
#include "font.h"
#include "login.h"
#include "game.h"
#include "other.h"

int main()
{
    game_p head = Init_List();

    srand(time(NULL));

    Init_Device();

    Login(head);

    return 0;
}