#include "myhead.h"
#include "list.h"
#include "font.h"
#include "other.h"
#include "game.h"
#include "login.h"


int game_over = 0;        //是否游戏结束了
char score_buff[10] = ""; //保存实时积分
int now_score = 0;        //实时的积分

//数组初始化，将所有的图片保存在一个数组中
char *bmp_files[] = {
    "./2.bmp", "./4.bmp",
    "./8.bmp", "./16.bmp",
    "./32.bmp", "./64.bmp",
    "./128.bmp", "./256.bmp",
    "./512.bmp", "./1024.bmp",
    "./2048.bmp"};

//棋盘矩阵的初始化
int array[4][4] = {0};

//游戏加载
void Game_Loading(game_p head)
{
    image = 2;
    show_bmp("./game_loading.bmp", 800, 480, 0, 0);
    int x = 100;
    while (x <= 650)
    {
        int time = (rand() % 100 + 1) * 10000;
        usleep(time);
        show_bmp("./loading.bmp", 40, 20, x += 20, 400);
    }
    Game_Begin(head);
}

//玩游戏
void Play_Game(game_p head)
{
    show_bmp("./game_beijing.bmp", 800, 480, 0, 0);
    show_bmp("./x.bmp", 40, 40, 759, 0);
    show_bmp("./restart_game.bmp", 40, 40, 10, 10);
    show_bmp("./back_main.bmp", 40, 40, 60, 10);
    bzero(array, sizeof(array));
    game_over = 0;
    init_matrix(head);
    now_score = 0;

    while (1)
    {
        // 3.设置字体输出框的大小颜色 创建一个宽为W,高为H的颜色为mapcolor的画布
        bm = createBitmapWithInit(150, 40, 4, 0xffc0cb00); //粉色
        // 4.把字体输出到输出框中 在画布的（X,Y）坐标开始中写一个fontcolor颜色的buf文字
        sprintf(score_buff, "%s%d", "积分:", now_score);
        fontPrint(f, bm, 5, 5, score_buff, 0x00000000, 100);
        // 5.把输出框的所有信息显示到LCD屏幕中 把字体框输出到LCD屏幕上,画框左上角的坐标为（640，110）
        show_font_to_lcd(Share_Addr, 640, 110, bm);

        //用来保存原来的矩阵值
        int matrix_v1[4][4];
        int i, j, flag = 0;
        for (i = 0; i < 4; ++i)
        {
            for (j = 0; j < 4; ++j)
            {
                matrix_v1[i][j] = array[i][j];
            }
        }
        //变换矩阵
        int direction = Get_Position(&x, &y);
        if (direction == 1)
        {
            fin_left();
        }
        else if (direction == 2)
        {
            fin_right();
        }
        else if (direction == 3)
        {
            fin_up();
        }
        else if (direction == 4)
        {
            fin_down();
        }

        for (i = 0; i < 4; ++i)
        {
            for (j = 0; j < 4; ++j)
            {
                if (matrix_v1[i][j] != array[i][j])
                {
                    flag = 1;
                    i = j = 4;
                }
            }
        }
        if (flag)
        {
            rand_matrix(head);
            draw_matrix(head);
        }
        else
        {
            draw_matrix(head);
        }
        game_over = move_judge();
        if (game_over == 1)
        {
            //保存积分
            game_p ret = Find_id(head, now_user);
            if (ret->data < now_score)
            {
                ret->data = now_score;
                Merge_List_Choice(head);
                FILE *fp = fopen("1.txt", "w+");
                char read_buff[50];

                game_p node = head->next;
                while (node != head)
                {
                    //把输入的账号密码进行拼接
                    sprintf(read_buff, "%s %s %d\n", node->user, node->password, node->data);
                    //把拼接好的数据覆盖写入到文本当中
                    fputs(read_buff, fp);
                    node = node->next;
                    bzero(read_buff, sizeof(read_buff));
                }
                fclose(fp);
            }

            usleep(500 * 1000);
            printf("game over~\n");
            show_bmp("./game_over.bmp", 440, 440, 185, 25);
            sleep(3);
            Game_Begin(head);
        }

        // x
        if (x >= 759 && y <= 40)
        {
            show_bmp("./welcome_next.bmp", 800, 480, 0, 0);
            sleep(1);
            show_bmp("./ending.bmp", 800, 480, 0, 0);
            Close_Device();
            exit(0);
        }

        //重新开始游戏
        else if ((x >= 10 && x < 50) && (y >= 10 && y < 50))
        {
            Play_Game(head);
        }

        //返回主菜单
        else if ((x >= 60 && x < 100) && (y >= 10 && y < 50))
        {
            Game_Begin(head);
        }
    }
}

//根据手指的滑动改变棋盘
int change_matrix()
{

    int direction = Get_Position(&x, &y);
    if (direction == 1)
    {
        fin_left();
    }
    else if (direction == 2)
    {
        fin_right();
    }
    else if (direction == 3)
    {
        fin_up();
    }
    else if (direction == 4)
    {
        fin_down();
    }
}

//手指左划后棋子移动及合并的方式
void fin_left()
{
    int i, j; // i为矩阵行下标，j为矩阵列下标
    int value, save_zero;
    for (i = 0; i < 4; i++)
    {
        value = 0; //保存遇到的方块的下标
        save_zero = 0;
        for (j = 0; j < 4; j++)
        {
            if (array[i][j] == 0)
                continue;
            if (value == 0)
                value = array[i][j];
            else
            {
                if (value == array[i][j])
                { //此时相当于产生了合并，分数要加上合并的数字
                    array[i][save_zero++] = value * 2;
                    now_score += value;
                    value = 0;
                }
                else
                {
                    array[i][save_zero++] = value;
                    value = array[i][j];
                }
            }
            array[i][j] = 0;
        }
        if (value != 0)
            array[i][save_zero] = value;
    }
}

//手指右划后棋子移动及合并的方式
void fin_right()
{
    int i, j; // i为矩阵行下标，j为矩阵列下标
    int value;
    int save_zero;
    for (i = 0; i < 4; i++)
    {
        value = 0;
        save_zero = 4 - 1;
        for (j = 4 - 1; j >= 0; j--)
        {
            if (array[i][j] == 0)
            {
                continue;
            }
            if (value == 0)
            {
                value = array[i][j];
            }
            else
            {
                if (value == array[i][j])
                { //此时相当于产生了合并，分数要加上合并的数字
                    array[i][save_zero--] = 2 * value;
                    now_score += value;
                    value = 0;
                }
                else
                {
                    array[i][save_zero--] = value;
                    value = array[i][j];
                }
            }
            array[i][j] = 0;
        }
        if (value != 0)
        {
            array[i][save_zero] = value;
        }
    }
}

//手指上划后棋子移动及合并的方式
void fin_up()
{

    int i, j; // i为矩阵行下标，j为矩阵列下标
    int value;
    int save_zero;

    for (j = 0; j < 4; j++)
    {
        value = 0;
        save_zero = 0;
        for (i = 0; i < 4; i++)
        {

            if (array[i][j] == 0)
            {
                continue;
            }
            if (value == 0)
            {
                value = array[i][j];
            }
            else
            {
                if (value == array[i][j])
                { //此时相当于产生了合并，分数要加上合并的数字
                    array[save_zero++][j] = 2 * value;
                    now_score += value;
                    value = 0;
                }
                else
                {
                    array[save_zero++][j] = value;
                    value = array[i][j];
                }
            }
            array[i][j] = 0;
        }
        if (value != 0)
        {
            array[save_zero][j] = value;
        }
    }
}

//手指下划后棋子移动及合并的方式
void fin_down()
{
    int i, j; // i为矩阵行下标，j为矩阵列下标
    int value;
    int save_zero;

    for (j = 0; j < 4; j++)
    {
        value = 0;
        save_zero = 4 - 1;
        for (i = 4 - 1; i >= 0; i--)
        {
            if (array[i][j] == 0)
            {
                continue;
            }
            if (value == 0)
            {
                value = array[i][j];
            }
            else
            {
                if (value == array[i][j])
                { //此时相当于产生了合并，分数要加上合并的数字
                    array[save_zero--][j] = 2 * value;
                    now_score += value;
                    value = 0;
                }
                else
                {
                    array[save_zero--][j] = value;
                    value = array[i][j];
                }
            }
            array[i][j] = 0;
        }
        if (value != 0)
        {
            array[save_zero][j] = value;
        }
    }
}

//移动之后随机产生一个数字填充到任意一个0的位置上
void rand_matrix(game_p head)
{
    int pos = (random() % rectangle_get_zero_num()) + 1;

    int s[] = {2, 4, 8, 2};
    int s_i = (random() % 4);

    rectangle_set_value(pos, s[s_i]);
    draw_matrix(head);
}

//初始化棋盘矩阵,在任意位置，填充1个数字(2,4,8)
void init_matrix(game_p head)
{
    int pos = (random() % rectangle_get_zero_num()) + 1;
    int s[] = {2, 4, 8, 2};
    int s_i = (random() % 3);
    rectangle_set_value(pos, s[s_i]);
    draw_matrix(head);
}

//求棋盘矩阵里面有多少个0
int rectangle_get_zero_num()
{
    int i, j, count = 0;
    for (i = 0; i < 4; i++)
    {
        for (j = 0; j < 4; j++)
        {
            if (array[i][j] == 0)
            {
                count++;
            }
        }
    }
    return count;
}

int rectangle_set_value(int z, int value)
{
    int i, j, count = 0;
    for (i = 0; i < 4; i++)
    {
        for (j = 0; j < 4; j++)
        {
            if (array[i][j] == 0)
            {
                count++;
                if (count == z)
                {
                    array[i][j] = value;
                    return 0;
                }
            }
        }
    }
}

//把棋盘矩阵在屏幕上显示出来
void draw_matrix(game_p head)
{
    int i, j;
    for (i = 0; i < 4; i++)
    {
        for (j = 0; j < 4; j++)
        {
            int x0, y0;
            x0 = 185; //棋盘矩阵左上角那个点的x轴坐标
            y0 = 25;  //棋盘矩阵左上角那个点的y轴坐标
            //如果此处元素的值为0，那么就显示
            if (array[i][j] == 0)
            {
                lcd_draw_dect(x0 + j * 110, y0 + i * 110, 80, 80,
                              0xff8080);
            }
            else
            {
                int f_index = get_bmp_files_index(array[i][j]);
                show_bmp(bmp_files[f_index], 80, 80, x0 + j * 110, y0 + i * 110);
                if (f_index == 10)
                {
                    //保存积分
                    game_p ret = Find_id(head, now_user);
                    if (ret->data < now_score)
                    {
                        ret->data = now_score;
                        Merge_List_Choice(head);
                        FILE *fp = fopen("1.txt", "w+");
                        char read_buff[50];

                        game_p node = head->next;
                        while (node != head)
                        {
                            //把输入的账号密码进行拼接
                            sprintf(read_buff, "%s %s %d\n", node->user, node->password, node->data);
                            //把拼接好的数据覆盖写入到文本当中
                            fputs(read_buff, fp);
                            node = node->next;
                            bzero(read_buff, sizeof(read_buff));
                        }
                        fclose(fp);
                    }

                    sleep(1);
                    show_bmp("./game_success.bmp", 440, 440, 185, 25);
                    sleep(3);
                    Game_Begin(head);
                }
            }
        }
    }
}

//判断是否还能移动
int move_judge()
{
    int i, j;
    if (rectangle_get_zero_num() != 0)
    {
        return 0;
    }
    for (i = 0; i < 4; i++)
    {
        for (j = 0; j < 4; j++)
        {
            if (j != 4 - 1)
            {
                if (array[i][j] == array[i][j + 1])
                {
                    return 0;
                }
            }
            if (i != 4 - 1)
            {
                if (array[i][j] == array[i + 1][j])
                {
                    return 0;
                }
            }
        }
    }
    return 1;
}

//根据要显示的数字来返回对应的文件名的下标
int get_bmp_files_index(int x)
{
    if (x == 2)
    {
        return 0;
    }
    else if (x == 4)
    {
        return 1;
    }
    else if (x == 8)
    {
        return 2;
    }
    else if (x == 16)
    {
        return 3;
    }
    else if (x == 32)
    {
        return 4;
    }
    else if (x == 64)
    {
        return 5;
    }
    else if (x == 128)
    {
        return 6;
    }
    else if (x == 256)
    {
        return 7;
    }
    else if (x == 512)
    {
        return 8;
    }
    else if (x == 1024)
    {
        return 9;
    }
    else if (x == 2048)
    {
        return 10;
    }

    return -1;
}

// 在屏幕上画一个矩形，并且用color这种颜色填充该矩形。
void lcd_draw_dect(int x0, int y0, int w, int h, int color)
{
    if (x0 < 0 || y0 < 0 || w < 0 || h < 0)
    {
        return;
    }
    if ((x0 + w > 800) || (y0 + h) > 480)
    {
        return;
    }
    int x_l, y_l;
    for (y_l = y0; y_l < y0 + h; y_l++)
    {
        for (x_l = x0; x_l < x0 + w; x_l++)
        {
            lcd_draw_point(x_l, y_l, color);
        }
    }
}

//在屏幕坐为(x, y)这个点，填充color颜色
void lcd_draw_point(int x_l, int y_l, int color)
{
    if (x_l >= 0 && x_l < 800 && y_l >= 0 && y_l < 480)
    {
        *(Share_Addr + 800 * y_l + x_l) = color;
    }
}

//游戏开始画面
void Game_Begin(game_p head)
{

    show_bmp("./game_beijing.bmp", 800, 480, 0, 0);
    show_bmp("./x.bmp", 40, 40, 759, 0);
    show_bmp("./score.bmp", 100, 40, 350, 160);
    show_bmp("./begine.bmp", 100, 40, 350, 220);
    show_bmp("./exit.bmp", 100, 40, 350, 280);
    show_bmp("./change_user.bmp", 100, 40, 350, 340);
    image = 3;
    while (1)
    {
        Get_Position(&x, &y);

        // x
        if (x >= 759 && y <= 40)
        {
            show_bmp("./welcome_next.bmp", 800, 480, 0, 0);
            sleep(1);
            show_bmp("./ending.bmp", 800, 480, 0, 0);
            Close_Device();
            exit(0);
        }

        //积分榜,还没排整齐
        else if (x >= 350 && x < 450 && y >= 160 && y < 200)
        {
            show_bmp("./game_success.bmp", 440, 440, 185, 25);
            char read_buff[100];
            // 3.设置字体输出框的大小颜色 创建一个宽为W,高为H的颜色为mapcolor的画布
            bm = createBitmapWithInit(440, 440, 4, 0xffc0cb00); //粉色
            // 4.把字体输出到输出框中 在画布的（X,Y）坐标开始中写一个fontcolor颜色的buf文字
            sprintf(read_buff, "%30s%40s", "用户", "积分");
            // sprintf(read_buff, "%s\t\t\t%d", "用户", now_score);
            fontPrint(f, bm, 0, 20, read_buff, 0x00000000, 400);
            // 5.把输出框的所有信息显示到LCD屏幕中 把字体框输出到LCD屏幕上,画框左上角的坐标为（640，110）
            show_font_to_lcd(Share_Addr, 185, 25, bm);
            printf("积分榜为:");
            Merge_List_Choice(head);
            Show_Score(head);
            game_p node=head->next;
            int length=20;
            int count=0;
            while(node!=head)
            {
                count++;
                bzero(read_buff, sizeof(read_buff));
                // 4.把字体输出到输出框中 在画布的（X,Y）坐标开始中写一个fontcolor颜色的buf文字
                sprintf(read_buff, "%30s%40d", node->user, node->data);
                fontPrint(f, bm, 0, length+=30, read_buff, 0x00000000, 400);
                // 5.把输出框的所有信息显示到LCD屏幕中 把字体框输出到LCD屏幕上,画框左上角的坐标为（640，110）
                show_font_to_lcd(Share_Addr, 185, 25, bm);
                node=node->next;
                //只显示十个
                if(count==10)
                {
                    break;
                }
            }
            show_bmp("./back_main.bmp", 40, 40, 60, 10);
            while(1)
            {
                Get_Position(&x, &y);
                //返回主菜单
                if ((x >= 60 && x < 100) && (y >= 10 && y < 50))
                {
                    Game_Begin(head);
                }
                // x
                else if (x >= 759 && y <= 40)
                {
                    show_bmp("./welcome_next.bmp", 800, 480, 0, 0);
                    sleep(1);
                    show_bmp("./ending.bmp", 800, 480, 0, 0);
                    Close_Device();
                    exit(0);
                }
            }
        }

        //退出游戏
        else if (x >= 350 && x < 450 && y >= 280 && y < 320)
        {
            show_bmp("./welcome_next.bmp", 800, 480, 0, 0);
            sleep(1);
            show_bmp("./ending.bmp", 800, 480, 0, 0);
            Close_Device();
            exit(0);
        }

        //开始游戏
        else if (x >= 350 && x < 450 && y >= 220 && y < 260)
        {
            Play_Game(head);
        }

        //切换用户
        else if (x >= 350 && x < 450 && y >= 340 && y < 380)
        {
            Login(head);
        }
    }
}
