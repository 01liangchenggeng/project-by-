/*
 * @Author: 梁程耿
 * @Date: 2022-08-05 08:33:57
 * @LastEditTime: 2022-08-10 12:51:06
 * @FilePath: \vmshare\kaifaban\Project\src\list.c
 * @Description:
 * Software:VSCode,env:
 * @version:
 */
#include "myhead.h"
#include "list.h"

//初始化链表
game_p Init_List()
{
    game_p head = (game_p)malloc(sizeof(game_s));
    if (head != NULL)
    {
        head->next = head;
        head->prev = head;
        return head;
    }
    else
    {
        printf("cycle list init fail\n");
        return NULL;
    }
}

//创建节点
game_p Creat_New_Node(char *id, char *pw, int read_data)
{
    game_p new_node = (game_p)malloc(sizeof(game_s));
    if (new_node != NULL)
    {
        strcpy(new_node->user, id);
        strcpy(new_node->password, pw);
        new_node->data=read_data;
        new_node->prev = new_node;
        new_node->next = new_node;
        return new_node;
    }
    else
    {
        printf("new node create fail\n");
        return NULL;
    }
}

//尾插插入节点
void Insert_New_Node_By_Tail(game_p Head, game_p New_Node)
{
    New_Node->next = Head;
    New_Node->prev = Head->prev;
    Head->prev->next = New_Node;
    Head->prev = New_Node;
}

//遍历链表
void Show_List(game_p Head)
{
    if (Head->next == Head && Head->prev == Head)
    {
        printf("list is empty\n");
        return;
    }
    game_p pos = Head->next;
    printf("============================================================\n");
    printf("\t\t账号\t\t\t密码\t\t分数\n");
    while (pos != Head)
    {
        printf("%20s%24s%16d\n", pos->user, pos->password, pos->data);
        pos = pos->next;
    }
}

//显示前十
void Show_Score(game_p Head)
{
    int count=0;
    if (Head->next == Head && Head->prev == Head)
    {
        printf("list is empty\n");
        return;
    }
    game_p pos = Head->next;
    printf("============================================================\n");
    printf("\t\t账号\t\t\t分数\n");
    while (pos != Head)
    {
        count++;
        printf("%20s%24d\n", pos->user, pos->data);
        pos = pos->next;
        if(count==10)
        {
            break;
        }
    }
}

// //任意位置增加节点
// void Add_Node_By_Any_Position(game_p head)
// {
//     printf("please input you want add this node to which node that had:");
//     int had_node;
//     scanf("%d", &had_node);
//     game_p node = head->next;
//     while (node != head)
//     {
//         if (node->data == had_node)
//         {
//             printf("the had node is found\n");
//             game_p add_node = New_Node();
//             node->next->prev = add_node;
//             add_node->next = node->next;
//             node->next = add_node;
//             add_node->prev = node;
//             return;
//         }
//         node = node->next;
//     }
//     printf("your input had node is wrong\n");
// }

//选择排序
void Merge_List_Choice(game_p head)
{
    int count = 0, i, j;
    game_p p = NULL;
    game_p q = NULL;
    game_p move = NULL;
    p = head;
    while (p->next != head)
    {
        count++;
        p = p->next;
    }
    p = head->next;
    for (i = 0; i < count - 1; i++)
    {
        move = p;
        q = move->next;
        game_p t = NULL;
        for (j = i + 1; j < count; j++) //要使用j<count的话，当有数据交换的时候j要j--；或者j<count换成q!=head
        {
            if (q->prev == move)
            {
                if (move->data < q->data)
                {
                    t = q->next;
                    move->prev->next = q;
                    q->prev = move->prev;
                    move->next = q->next;
                    q->next->prev = move;
                    q->next = move;
                    move->prev = q;
                    p = q;
                    move = p;
                    q = t->prev;
                    j--;
                }
                else
                {
                    q = q->next;
                }
            }
            else
            {
                if (move->data > q->data)
                {
                    t = q->next;
                    game_p a = move->next;
                    game_p b = q->prev;
                    move->prev->next = q;
                    q->prev = move->prev;
                    move->next = q->next;
                    q->next->prev = move;
                    q->next = a;
                    a->prev = q;
                    b->next = move;
                    move->prev = b;
                    p = q;
                    move = p;
                    q = t->prev;
                    j--;
                }
                else
                {
                    q = q->next;
                }
            }
        }
        p = p->next;
    }
}

//删除节点
void Delete_Node(game_p Pos)
{
    Pos->prev->next = Pos->next;
    Pos->next->prev = Pos->prev;
    Pos->prev = NULL;
    Pos->next = NULL;
    free(Pos);
}

//寻找相同的账号
game_p Find_id(game_p Head, char *id)
{
    if (Head->next == Head)
    {
        return NULL;
    }
    game_p pos = Head->next;
    while (pos != Head)
    {
        if (strcmp(pos->user, id) == 0)
        {
            return pos;
        }
        pos = pos->next;
    }
    return NULL; // 没有数据
}
