#include "myhead.h"
#include "list.h"
#include "font.h"
#include "other.h"
#include "game.h"
#include "login.h"

int flag_user = 0;            //点击输入账号时键盘弹出收回
int flag_password = 0;        //点击输入密码时键盘弹出收回
int flag_login = 0;           //点击登录时键盘弹出收回
int flag_register = 0;        //点击注册时键盘弹出收回
int flag_complete = 0;        //记录是否按下完成键
int flag_refuse = 0;          //记录是否按下取消键
int count_user_input = 0;     //记录输入多少个账号数字
int count_password_input = 0; //记录输入多少个密码数字
char user[15] = "";           //记录输入的账号
char password[15] = "";       //记录输入的密码
char now_user[15] = "";       //保存进行游戏时的用户

//登录注册页面
// bug:输入后点击取消不能再次输入
void Login(game_p head)
{
    now_score = 0;
    image = 1;
    show_bmp("./login_beijing.bmp", 800, 480, 0, 0);
    show_bmp("./input_user.bmp", 200, 50, 100, 90);
    show_bmp("./input_password.bmp", 200, 50, 100, 160);
    show_bmp("./user.bmp", 80, 50, 10, 90);
    show_bmp("./password.bmp", 80, 50, 10, 160);
    show_bmp("./login.bmp", 80, 50, 100, 230);
    show_bmp("./register.bmp", 80, 50, 220, 230);

    //一开始进入页面就先加载文本数据进链表中，不然如果先点击登录是没有数据的
    FILE *fp = fopen("1.txt", "a+");
    //把文档中数据加载到链表当中
    fseek(fp, 0, SEEK_SET);
    char read_buff[100];
    char read_id[40];
    char read_pw[40];
    int read_data = 0;
    game_p new = NULL;
    //如果返回的是NULL 则停止循环
    while (fgets(read_buff, sizeof(read_buff), fp))
    {
        //拆分数据,从read_buff当中拆分数据
        sscanf(read_buff, "%s %s %d", read_id, read_pw, &read_data);
        //把所有的数据加载到链表当中
        new = Creat_New_Node(read_id, read_pw, read_data);
        Insert_New_Node_By_Tail(head, new);

        bzero(read_buff, sizeof(read_buff));
        bzero(read_id, sizeof(read_id));
        bzero(read_pw, sizeof(read_pw));
    }
    fclose(fp);

    while (1)
    {
        Get_Position(&x, &y);

        //手指在输入账号框
        if ((x >= 100 && x < 300) && (y >= 90 && y < 140))
        {
            if (flag_user == 0)
            {
                if (strlen(password) == 0)
                {
                    show_bmp("./input_password.bmp", 200, 50, 100, 160);
                    bzero(password, sizeof(password));
                    bzero(user, sizeof(user));
                }
                count_password_input = 0;
                count_user_input = 0;
                flag_complete = 0;
                flag_refuse = 0;
                flag_password = 0;
                show_bmp("./white.bmp", 200, 50, 100, 90);
                show_bmp("./login_beijing.bmp", 400, 300, 350, 90);
                usleep(100 * 1000); //让程序停一会更像键盘弹出
                show_bmp("./keyborad.bmp", 400, 300, 350, 90);
                flag_user = 1;
                continue;
            }
            if (flag_user == 1)
            {
                show_bmp("./login_beijing.bmp", 400, 300, 350, 90);
                show_bmp("./input_user.bmp", 200, 50, 100, 90);
                flag_user = 0;
                continue;
            }
        }

        //手指在输入密码框
        else if ((x >= 100 && x < 300) && (y >= 160 && y < 210))
        {
            if (flag_password == 0)
            {
                if (strlen(user) == 0)
                {
                    show_bmp("./input_user.bmp", 200, 50, 100, 90);
                    bzero(password, sizeof(password));
                    bzero(user, sizeof(user));
                }
                flag_user = 0;
                show_bmp("./white.bmp", 200, 50, 100, 160);
                show_bmp("./login_beijing.bmp", 400, 300, 350, 90);
                usleep(100 * 1000);
                show_bmp("./keyborad.bmp", 400, 300, 350, 90);
                count_password_input = 0;
                count_user_input = 0;
                flag_complete = 0;
                flag_refuse = 0;
                flag_password = 1;
                flag_refuse = 0;
                flag_complete = 0;
                continue;
            }
            if (flag_password == 1)
            {
                show_bmp("./login_beijing.bmp", 400, 300, 350, 90);
                show_bmp("./input_password.bmp", 200, 50, 100, 160);
                flag_password = 0;
                continue;
            }
        }

        //点击登录
        else if ((x >= 100 && x < 180) && (y >= 230 && y < 280))
        {
            if (flag_complete == 1)
            {
                if (strlen(user) == 0 || strlen(password) == 0)
                {
                    show_bmp("./login_fail.bmp", 400, 300, 350, 90);
                    sleep(2);
                    show_bmp("./login_beijing.bmp", 400, 300, 350, 90);
                    show_bmp("./input_password.bmp", 200, 50, 100, 160);
                    show_bmp("./input_user.bmp", 200, 50, 100, 90);
                    bzero(user, sizeof(user));
                    bzero(password, sizeof(password));
                    count_user_input = 0;
                    count_password_input = 0;
                }
                else
                {
                    game_p ret = Find_id(head, user);
                    if (ret != NULL)
                    {
                        if (strcmp(ret->password, password) == 0)
                        {
                            strcpy(now_user, ret->user);
                            show_bmp("./login_success.bmp", 400, 300, 350, 90);
                            show_bmp("./input_password.bmp", 200, 50, 100, 160);
                            show_bmp("./input_user.bmp", 200, 50, 100, 90);
                            sleep(2);
                            show_bmp("./login_beijing.bmp", 400, 300, 350, 90);

                            flag_user = 0;
                            flag_password = 0;
                            flag_login = 0;
                            flag_register = 0;
                            flag_complete = 0;
                            flag_refuse = 0;
                            count_user_input = 0;
                            count_password_input = 0;
                            bzero(user, sizeof(user));
                            bzero(password, sizeof(password));
                            Game_Loading(head);
                        }
                        //找不到该用户
                        else
                        {
                            show_bmp("./login_fail.bmp", 400, 300, 350, 90);
                            sleep(2);
                            show_bmp("./login_beijing.bmp", 400, 300, 350, 90);
                            show_bmp("./input_password.bmp", 200, 50, 100, 160);
                            show_bmp("./input_user.bmp", 200, 50, 100, 90);
                            bzero(user, sizeof(user));
                            bzero(password, sizeof(password));
                            count_user_input = 0;
                            count_password_input = 0;
                        }
                    }
                    else
                    {
                        show_bmp("./login_fail.bmp", 400, 300, 350, 90);
                        sleep(2);
                        show_bmp("./login_beijing.bmp", 400, 300, 350, 90);
                        show_bmp("./input_password.bmp", 200, 50, 100, 160);
                        show_bmp("./input_user.bmp", 200, 50, 100, 90);
                        flag_user = 0;
                        flag_password = 0;
                        bzero(user, sizeof(user));
                        bzero(password, sizeof(password));
                        count_user_input = 0;
                        count_password_input = 0;
                    }
                }
                bzero(user, sizeof(user));
                bzero(password, sizeof(password));
                count_user_input = 0;
                count_password_input = 0;
                flag_user = 0;
                flag_password = 0;
            }
            else
            {
                show_bmp("./login_beijing.bmp", 400, 300, 350, 90);
                show_bmp("./input_password.bmp", 200, 50, 100, 160);
                show_bmp("./input_user.bmp", 200, 50, 100, 90);
                flag_user = 0;
                flag_password = 0;
                bzero(user, sizeof(user));
                bzero(password, sizeof(password));
                count_user_input = 0;
                count_password_input = 0;
            }
        }

        //点击注册
        else if ((x > 220 && x < 300) && (y >= 230 && y < 280))
        {
            if (flag_complete == 1) //当点击了完成按钮后
            {
                if (strlen(user) == 0 || strlen(password) == 0) //账号或密码有一个没有输入
                {
                    show_bmp("./register_fail.bmp", 400, 300, 350, 90);
                    sleep(2);
                    show_bmp("./login_beijing.bmp", 400, 300, 350, 90);
                    show_bmp("./input_password.bmp", 200, 50, 100, 160);
                    show_bmp("./input_user.bmp", 200, 50, 100, 90);
                }
                else
                {
                    FILE *fp = fopen("1.txt", "a+");
                    char read_buff[100];
                    int read_data = 0;

                    bzero(read_buff, sizeof(read_buff));
                    game_p ret = Find_id(head, user);
                    if (ret == NULL)
                    {
                        //把输入的账号密码进行拼接
                        sprintf(read_buff, "%s %s %d\n", user, password, read_data);
                        //把拼接好的数据写入到文本当中
                        fputs(read_buff, fp);
                        //把文档中数据加载到链表当中
                        fseek(fp, 0, SEEK_SET);
                        char read_id[40];
                        char read_pw[40];
                        bzero(read_buff, sizeof(read_buff));

                        game_p new = NULL;
                        //如果返回的是NULL 则停止循环
                        while (fgets(read_buff, sizeof(read_buff), fp))
                        {
                            bzero(read_id, sizeof(read_id));
                            bzero(read_pw, sizeof(read_pw));
                            //拆分数据,从readdata当中拆分数据
                            sscanf(read_buff, "%s %s %d", read_id, read_pw, &read_data);
                            //把注册数据加载到链表当中
                            game_p reg = Find_id(head, read_id);
                            if (reg == NULL)
                            {
                                new = Creat_New_Node(read_id, read_pw, read_data);
                                Insert_New_Node_By_Tail(head, new);
                            }
                            bzero(read_buff, sizeof(read_buff));
                        }
                        show_bmp("./register_success.bmp", 400, 300, 350, 90);
                        show_bmp("./input_password.bmp", 200, 50, 100, 160);
                        show_bmp("./input_user.bmp", 200, 50, 100, 90);
                        sleep(2);
                        show_bmp("./login_beijing.bmp", 400, 300, 350, 90);
                        Show_List(head);
                    }
                    else
                    {
                        show_bmp("./login_beijing.bmp", 400, 300, 350, 90);
                        show_bmp("./input_password.bmp", 200, 50, 100, 160);
                        show_bmp("./input_user.bmp", 200, 50, 100, 90);
                        bzero(user, sizeof(user));
                        bzero(password, sizeof(password));
                        count_user_input = 0;
                        count_password_input = 0;
                        flag_user = 0;
                        flag_password = 0;
                    }
                    fclose(fp);
                }
                bzero(user, sizeof(user));
                bzero(password, sizeof(password));
                count_user_input = 0;
                count_password_input = 0;
                flag_user = 0;
                flag_password = 0;
            }
            else
            {
                show_bmp("./login_beijing.bmp", 400, 300, 350, 90);
                show_bmp("./input_password.bmp", 200, 50, 100, 160);
                show_bmp("./input_user.bmp", 200, 50, 100, 90);
                bzero(user, sizeof(user));
                bzero(password, sizeof(password));
                count_user_input = 0;
                count_password_input = 0;
                flag_user = 0;
                flag_password = 0;
            }
        }

        //手指在键盘区域
        else if ((x >= 350 || x < 750) || (y >= 90 || y < 390))
        {
            if ((flag_user == 1 || flag_password == 1) && (flag_complete == 0 && flag_refuse == 0))
            {
                //键盘上的1
                if ((x >= 350 && x < 483) && (y >= 90 && y < 145))
                {
                    if (flag_user == 1)
                    {
                        if (strlen(user) < 10)
                        {
                            strcat(user, "1");
                            show_bmp("./number_1.bmp", 16, 32, 110 + 16 * count_user_input + 2, 100);
                            count_user_input++;
                        }
                        else
                        {
                            printf("账号已达最大位数\n");
                        }
                    }
                    else if (flag_password == 1)
                    {
                        if (strlen(password) < 6)
                        {
                            strcat(password, "1");
                            show_bmp("./number_1.bmp", 16, 32, 110 + 16 * count_password_input + 2, 170);
                            count_password_input++;
                        }
                        else
                        {
                            printf("密码已达最大位数\n");
                        }
                    }
                }
                //键盘上的4
                else if ((x >= 350 && x < 483) && (y > 146 && y < 201))
                {
                    if (flag_user == 1)
                    {
                        if (strlen(user) < 10)
                        {
                            strcat(user, "4");
                            show_bmp("./number_4.bmp", 16, 32, 110 + 16 * count_user_input + 2, 100);
                            count_user_input++;
                        }
                        else
                        {
                            printf("账号已达最大位数\n");
                        }
                    }
                    else if (flag_password == 1)
                    {
                        if (strlen(password) < 6)
                        {
                            strcat(password, "4");
                            show_bmp("./number_4.bmp", 16, 32, 110 + 16 * count_password_input + 2, 170);
                            count_password_input++;
                        }
                        else
                        {
                            printf("密码已达最大位数\n");
                        }
                    }
                }
                //键盘上的7
                else if ((x >= 350 && x < 483) && (y > 202 && y < 257))
                {
                    if (flag_user == 1)
                    {
                        if (strlen(user) < 10)
                        {
                            strcat(user, "7");
                            show_bmp("./number_7.bmp", 16, 32, 110 + 16 * count_user_input + 2, 100);
                            count_user_input++;
                        }
                        else
                        {
                            printf("账号已达最大位数\n");
                        }
                    }
                    else if (flag_password == 1)
                    {
                        if (strlen(password) < 6)
                        {
                            strcat(password, "7");
                            show_bmp("./number_7.bmp", 16, 32, 110 + 16 * count_password_input + 2, 170);
                            count_password_input++;
                        }
                        else
                        {
                            printf("密码已达最大位数\n");
                        }
                    }
                }
                //键盘上的.
                else if ((x >= 350 && x < 483) && (y > 258 && y < 311))
                {
                }
                //键盘上的取消
                if ((x >= 350 && x < 483) && (y > 312 && y < 390))
                {
                    show_bmp("./login_beijing.bmp", 400, 300, 350, 90);
                    show_bmp("./input_user.bmp", 200, 50, 100, 90);
                    show_bmp("./input_password.bmp", 200, 50, 100, 160);
                    flag_refuse = 1;
                }
                //键盘上的2
                else if ((x >= 483 && x < 616) && (y >= 90 && y < 145))
                {
                    if (flag_user == 1)
                    {
                        if (strlen(user) < 10)
                        {
                            strcat(user, "2");
                            show_bmp("./number_2.bmp", 16, 32, 110 + 16 * count_user_input + 2, 100);
                            count_user_input++;
                        }
                        else
                        {
                            printf("账号已达最大位数\n");
                        }
                    }
                    else if (flag_password == 1)
                    {
                        if (strlen(password) < 6)
                        {
                            strcat(password, "2");
                            show_bmp("./number_2.bmp", 16, 32, 110 + 16 * count_password_input + 2, 170);
                            count_password_input++;
                        }
                        else
                        {
                            printf("密码已达最大位数\n");
                        }
                    }
                }
                //键盘上的5
                else if ((x >= 483 && x < 616) && (y >= 146 && y < 201))
                {
                    if (flag_user == 1)
                    {
                        if (strlen(user) < 10)
                        {
                            strcat(user, "5");
                            show_bmp("./number_5.bmp", 16, 32, 110 + 16 * count_user_input + 2, 100);
                            count_user_input++;
                        }
                        else
                        {
                            printf("账号已达最大位数\n");
                        }
                    }
                    else if (flag_password == 1)
                    {
                        if (strlen(password) < 6)
                        {
                            strcat(password, "5");
                            show_bmp("./number_5.bmp", 16, 32, 110 + 16 * count_password_input + 2, 170);
                            count_password_input++;
                        }
                        else
                        {
                            printf("密码已达最大位数\n");
                        }
                    }
                }
                //键盘上的8
                else if ((x >= 483 && x < 616) && (y >= 202 && y < 257))
                {
                    if (flag_user == 1)
                    {
                        if (strlen(user) < 10)
                        {
                            strcat(user, "8");
                            show_bmp("./number_8.bmp", 16, 32, 110 + 16 * count_user_input + 2, 100);
                            count_user_input++;
                        }
                        else
                        {
                            printf("账号已达最大位数\n");
                        }
                    }
                    else if (flag_password == 1)
                    {
                        if (strlen(password) < 6)
                        {
                            strcat(password, "8");
                            show_bmp("./number_8.bmp", 16, 32, 110 + 16 * count_password_input + 2, 170);
                            count_password_input++;
                        }
                        else
                        {
                            printf("密码已达最大位数\n");
                        }
                    }
                }
                //键盘上的0
                else if ((x >= 483 && x < 616) && (y >= 258 && y < 311))
                {
                    if (flag_user == 1)
                    {
                        if (strlen(user) < 10)
                        {
                            strcat(user, "0");
                            show_bmp("./number_0.bmp", 16, 32, 110 + 16 * count_user_input + 2, 100);
                            count_user_input++;
                        }
                        else
                        {
                            printf("账号已达最大位数\n");
                        }
                    }
                    else if (flag_password == 1)
                    {
                        if (strlen(password) < 6)
                        {
                            strcat(password, "0");
                            show_bmp("./number_0.bmp", 16, 32, 110 + 16 * count_password_input + 2, 170);
                            count_password_input++;
                        }
                        else
                        {
                            printf("密码已达最大位数\n");
                        }
                    }
                }
                //键盘上的清除
                else if ((x >= 483 && x < 616) && (y >= 312 && y < 390))
                {
                    if (flag_user == 1)
                    {
                        show_bmp("./white.bmp", 200, 50, 100, 90);
                        bzero(user, sizeof(user));
                    }
                    else if (flag_password == 1)
                    {
                        show_bmp("./white.bmp", 200, 50, 100, 160);
                        bzero(password, sizeof(password));
                    }
                    count_password_input = 0;
                    count_user_input = 0;
                }
                //键盘上的3
                else if ((x >= 616 && x < 749) && (y >= 90 && y < 145))
                {
                    if (flag_user == 1)
                    {
                        if (strlen(user) < 10)
                        {
                            strcat(user, "3");
                            show_bmp("./number_3.bmp", 16, 32, 110 + 16 * count_user_input + 2, 100);
                            count_user_input++;
                        }
                        else
                        {
                            printf("账号已达最大位数\n");
                        }
                    }
                    else if (flag_password == 1)
                    {
                        if (strlen(password) < 6)
                        {
                            strcat(password, "3");
                            show_bmp("./number_3.bmp", 16, 32, 110 + 16 * count_password_input + 2, 170);
                            count_password_input++;
                        }
                        else
                        {
                            printf("密码已达最大位数\n");
                        }
                    }
                }
                //键盘上的6
                else if ((x >= 616 && x < 749) && (y >= 146 && y < 201))
                {
                    if (flag_user == 1)
                    {
                        if (strlen(user) < 10)
                        {
                            strcat(user, "6");
                            show_bmp("./number_6.bmp", 16, 32, 110 + 16 * count_user_input + 2, 100);
                            count_user_input++;
                        }
                        else
                        {
                            printf("账号已达最大位数\n");
                        }
                    }
                    else if (flag_password == 1)
                    {
                        if (strlen(password) < 6)
                        {
                            strcat(password, "6");
                            show_bmp("./number_6.bmp", 16, 32, 110 + 16 * count_password_input + 2, 170);
                            count_password_input++;
                        }
                        else
                        {
                            printf("密码已达最大位数\n");
                        }
                    }
                }
                //键盘上的9
                else if ((x >= 616 && x < 749) && (y >= 202 && y < 257))
                {
                    if (flag_user == 1)
                    {
                        if (strlen(user) < 10)
                        {
                            strcat(user, "9");
                            show_bmp("./number_9.bmp", 16, 32, 110 + 16 * count_user_input + 2, 100);
                            count_user_input++;
                        }
                        else
                        {
                            printf("账号已达最大位数\n");
                        }
                    }
                    else if (flag_password == 1)
                    {
                        if (strlen(password) < 6)
                        {
                            strcat(password, "9");
                            show_bmp("./number_9.bmp", 16, 32, 110 + 16 * count_password_input + 2, 170);
                            count_password_input++;
                        }
                        else
                        {
                            printf("密码已达最大位数\n");
                        }
                    }
                }
                //键盘上的X
                else if ((x >= 616 && x < 749) && (y >= 258 && y < 311))
                {
                    if (flag_user == 1)
                    {
                        if (count_user_input > 0)
                        {
                            count_user_input--;
                            show_bmp("./cover.bmp", 16, 32, 110 + 16 * count_user_input + 2, 100);
                            int i;
                            for (i = 0; i < strlen(user) - 1; i++)
                            {
                            }
                            user[i] = '\0';
                        }
                    }
                    else if (flag_password == 1)
                    {
                        if (count_password_input > 0)
                        {
                            count_password_input--;
                            show_bmp("./cover.bmp", 16, 32, 110 + 16 * count_password_input + 2, 170);
                            int i;
                            for (i = 0; i < strlen(password) - 1; i++)
                            {
                            }
                            password[i] = '\0';
                        }
                    }
                }
                //键盘上的完成
                else if ((x >= 616 && x < 749) && (y >= 312 && y < 390))
                {
                    show_bmp("./login_beijing.bmp", 400, 300, 350, 90);
                    flag_complete = 1;
                }
                continue;
            }
        }

        //手指在其他地方
        else if ((x < 350 || x >= 750) || (y < 90 || y > 390))
        {
            show_bmp("./login_beijing.bmp", 400, 300, 350, 90);
            show_bmp("./input_user.bmp", 200, 50, 100, 90);
            show_bmp("./input_password.bmp", 200, 50, 100, 160);
            continue;
        }
    }
}
