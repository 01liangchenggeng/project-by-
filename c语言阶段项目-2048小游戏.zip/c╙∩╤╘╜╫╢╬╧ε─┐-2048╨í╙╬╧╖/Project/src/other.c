#include "myhead.h"
#include "list.h"
#include "font.h"
#include "other.h"
#include "game.h"
#include "login.h"

int x, y;               //记录刚开始点击时的的x，y坐标
int image = 0;          //记录处于哪个画面

int *Share_Addr = NULL; //设置共享内存
int Lcd_Fd;             //记录打开设备状态
int touch_fd;           //记录打开触摸屏状态

//初始化设备
void Init_Device()
{
    //打开文件
    int Lcd_Fd = open(device_path, O_RDWR);

    touch_fd = open(touch_path, O_RDWR);
    if (touch_fd == -1)
    {
        perror("open touch fail\n");
        return;
    }

    //申请共享空间
    Share_Addr = mmap(
        NULL,
        480 * 800 * 4,
        PROT_READ | PROT_WRITE,
        MAP_SHARED,
        Lcd_Fd,
        0);

    // 1.初始化字库
    f = fontLoad("/usr/share/fonts/DroidSansFallback.ttf");
    // 2.设置字体的大小
    fontSetSize(f, 24);
    // 3.设置字体输出框的大小颜色 创建一个宽为W,高为H的颜色为mapcolor的画布
    bm = createBitmapWithInit(150, 40, 4, 0xffc0cb00); //粉色
}

//加载图片到显示屏
int show_bmp(char *pathname, int width, int height, int x, int y)
{

    int ret;
    char head_buf[54] = {0};
    int i, j;

    char bmp_buf[width * height * 3];   //用于存放图片信息
    bzero(bmp_buf, width * height * 3); //清空数组,用于存放图片信息

    int lcd_buf[width * height];    // LCD屏数存放图片信息.
    bzero(lcd_buf, width * height); //清空数组,用于LCD显示屏内存映射

    int bmp_fd = open(pathname, O_RDWR); //打开指定路径图片
    if (bmp_fd < 0)                      //判断是否打开成功
    {
        printf("open bmp failed\n");
        return -1;
    }
    read(bmp_fd, head_buf, 54);                //因为图片数据前54个字节为图片信息,读取54字节
                                               //跳过54字节，也可以使用lseek()函数偏移光标指针,跳过54字节
    read(bmp_fd, bmp_buf, width * height * 3); //读取图片像素色彩信息.

    for (j = 0; j < height; j++) //处理图片数据,将图片像素信息倒序,
    {                            //原本图片直接写入显示在开发板当中是倒的.经过处理,图片会正序过来.(字节对齐)
        for (i = 0; i < width; i++)
        {
            lcd_buf[i + j * width] = bmp_buf[3 * (i + j * width) + 0];
            lcd_buf[i + j * width] |= bmp_buf[3 * (i + j * width) + 1] << 8;
            lcd_buf[i + j * width] |= bmp_buf[3 * (i + j * width) + 2] << 16;
        }
    }

    //将处理好的图片数据写入到LCD屏,进行映射.
    for (j = 0; j < height; j++)
    {
        for (i = 0; i < width; i++)
        {
            *(Share_Addr + i + j * 800 + x + y * 800) = lcd_buf[i + (height - 1 - j) * width];
        }
    }

    close(bmp_fd); //关闭图片
    return 0;      //结束该函数
}

//关闭设备
void Close_Device()
{
    close(Lcd_Fd);
    munmap(Share_Addr, 480 * 800 * 4);

    // 6.销毁所有初始化的东西
    // 关闭字体
    fontUnload(f);
    // 关闭bitmap
    destroyBitmap(bm);
}

//获取点击的坐标轴以及滑动手势
int Get_Position(int *x, int *y)
{
    int x_1;        //记录滑动后的x坐标
    int y_1;        //记录滑动后的y坐标
    int flag_x = 0; //记录X轴按下的坐标点
    int flag_y = 0; //记录Y轴按下的坐标点

    //读取驱动文件的内容
    struct input_event touch; //用于储存驱动文件当中发生的事件
    while (1)
    {
        read(touch_fd, &touch, sizeof(touch));
        // 判断发生了什么事件
        if (touch.type == EV_ABS) //发生触摸屏事件
        {
            if (touch.code == ABS_X) // X轴事件
            {
                if (flag_x == 0)
                {
                    x_1 = touch.value * 800 / 1024;
                    flag_x = 1;
                }
                *x = touch.value * 800 / 1024;
            }
            if (touch.code == ABS_Y) // Y轴事件
            {
                if (flag_y == 0)
                {
                    y_1 = touch.value * 480 / 614;
                    flag_y = 1;
                }
                *y = touch.value * 480 / 614;
            }
        }
        //判断手指是否抬起
        if (touch.type == EV_KEY && touch.code == BTN_TOUCH && touch.value == 0)
        {
            break;
        }
    }
    if (image != 1 && image != 2)
    {
        //从左往右
        if (x_1 - (*x) <= -50)
        {
            return 2;
        }
        //从右往左
        else if (x_1 - (*x) >= 50)
        {
            return 1;
        }
        //从上到下
        else if (y_1 - (*y) <= -50)
        {
            return 4;
        }
        //从下到上
        else if (y_1 - (*y) >= 50)
        {
            return 3;
        }
    }
}
